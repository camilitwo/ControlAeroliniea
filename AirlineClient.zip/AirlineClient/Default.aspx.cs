﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ServiceReference1;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    ServiceAirlineSoapClient ws = new ServiceAirlineSoapClient();
    protected void Page_Load(object sender, EventArgs e)
    {

        txt_nombre.Text = "";
        txt_numAsiento.Text = "";
        txt_numVuelo.Text = "";
        txt_pasaporte.Text = "";

        DataTable dt = ws.getDataAirline();
        gv_default.Columns.Clear();
        gv_default.DataSource = dt;
        gv_default.DataBind();

        btn_grabar.Visible = false;
        txt_nombre.Visible = false;
        txt_numAsiento.Visible = false;
        txt_numVuelo.Visible = false;
        txt_pasaporte.Visible = false;
        btn_cancel.Visible = false;
        lbl_resp.Text = "";

    }

    protected void btn_solRes_Click(object sender, EventArgs e)
    {
        btn_grabar.Visible = true;
        txt_nombre.Visible = true;
        txt_numAsiento.Visible = true;
        txt_numVuelo.Visible = true;
        txt_pasaporte.Visible = true;
        btn_cancel.Visible = true;
    }

    protected void btn_grabar_Click(object sender, EventArgs e)
    {
        lbl_resp.Text = ws.requestReservation(txt_nombre.Text, txt_numAsiento.Text, txt_numVuelo.Text, txt_pasaporte.Text);

        DataTable dt = ws.getDataAirline();
        gv_default.Columns.Clear();
        gv_default.DataSource = dt;
        gv_default.DataBind();
    }

    protected void btn_cancel_Click(object sender, EventArgs e)
    {
        txt_nombre.Text = "";
        txt_numAsiento.Text = "";
        txt_numVuelo.Text = "";
        txt_pasaporte.Text = "";
        btn_grabar.Visible = false;
        btn_cancel.Visible = false;
        txt_nombre.Visible = false;
        txt_numAsiento.Visible = false;
        txt_numVuelo.Visible = false;
        txt_pasaporte.Visible = false;
    }
}