﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OleDb;
namespace Aerolinea
{
    public class Vuelos
    {
        string destino = "";
        string fech_hora_lleg = "";
        string fech_hora_part = "";
        string num_vuelo = "";
        string origen = "";
        public Asientos obj_asientos = new Asientos();
        public void VerListadoVuelos()
        {
        }
    }
    public class Asientos
    {
        string estado = "";
        string num_asiento = "";
        string num_vuelo = "";
        string tipo = "";
        public Reservas obj_reservas = new Reservas();
        public DataTable MostrarAsientosDisponibles(ref string error)
        {
            string sql = "";
            sql = "SELECT * FROM tb_asientos WHERE estado='D'"; // Consulta sql
            string string_de_conexion = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" +
                                   HttpContext.Current.Server.MapPath(@"App_Data\Aerolinea.mdb") + ";";
            OleDbConnection cnn = new OleDbConnection(string_de_conexion);
            OleDbDataAdapter da = new OleDbDataAdapter(sql, cnn);
            DataTable ds = new DataTable();
            try // Ambiente controlado de ejecución, por errores externos
            {
                cnn.Open();
                da.Fill(ds);
            }
            catch (OleDbException ex)
            {
                error = ex.Message;
            }
            finally
            {
                cnn.Close();
            }
            ds.TableName = "datos";
            return ds;
        }
    }
    public class Reservas
    {
        string nombre = "";
        string num_asiento = "";
        string num_vuelo = "";
        string pasaporte = "";
        public void CancelarReserva()
        {
        }
        public void MostrarReservas()
        {
        }
        public string SolicitarReserva(string nombre, string num_asiento, string
        num_vuelo, string pasaporte)
        {
            string sql_ins = "", sql_upd = "", resultado = "OK";
            int cantidad = 0;
            sql_ins = "INSERT INTO tb_Reserva(num_vuelo, num_asiento, pasaporte, nombre) VALUES('" + num_vuelo + "', '" + num_asiento + "','" + pasaporte + "','" + nombre + "')"; // Consulta sql
            sql_upd = "UPDATE tb_asientos SET estado='R' WHERE num_vuelo='" +
            num_vuelo + "' AND num_asiento='" + num_asiento + "'"; // Consulta sql
            string string_de_conexion = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source=" +
                                   HttpContext.Current.Server.MapPath(@"App_Data\Aerolinea.mdb") + ";";
            OleDbConnection cnn = new OleDbConnection(string_de_conexion);
            OleDbCommand da_ins = new OleDbCommand(sql_ins, cnn);
            OleDbCommand da_upd = new OleDbCommand(sql_upd, cnn);
            try // Ambiente controlado de ejecución, por errores externos
            {
                cnn.Open();
                cantidad = da_ins.ExecuteNonQuery();
                cantidad = da_upd.ExecuteNonQuery();
            }
            catch (OleDbException ex)
            {
                resultado = ex.Message;
            }
            finally
            {
                cnn.Close();
            }
            if (resultado == "OK")
            {
                resultado = resultado + "- " + Convert.ToString(cantidad) + " reserva realizada.";
            }
            return resultado;
        }
    }
}
