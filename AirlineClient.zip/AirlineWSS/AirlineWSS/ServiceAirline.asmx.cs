﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using Aerolinea;
using System.Data;

namespace AirlineWSS
{
    /// <summary>
    /// Descripción breve de ServiceAirline
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Para permitir que se llame a este servicio web desde un script, usando ASP.NET AJAX, quite la marca de comentario de la línea siguiente. 
    // [System.Web.Script.Services.ScriptService]
    public class ServiceAirline : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hola a todos";
        }

        [WebMethod]
        public DataTable getDataAirline()
        {
            Asientos asientos = new Asientos();
            string error = "";
            return asientos.MostrarAsientosDisponibles(ref error);
        }

        [WebMethod]
        public string requestReservation(string nombre, string num_asiento, string
            num_vuelo, string pasaporte)
        {
            Reservas reservas = new Reservas();
            return reservas.SolicitarReserva(nombre, num_asiento, num_vuelo, pasaporte);
        }
    }
}
